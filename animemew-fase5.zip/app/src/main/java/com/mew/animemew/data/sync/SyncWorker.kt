package com.mew.animemew.data.sync

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.mew.animemew.data.airing.AiringController
import com.mew.animemew.data.local.AnimeDatabase
import com.mew.animemew.notifications.AnimeNotificationsManager

// =========================================================
//  SyncWorker — se ejecuta cada 15 min en background.
//  Solo hace algo si hay sesión activa.
//
//  NUEVO Fase 5: después de checkAllWaiting(), revisa qué animes
//  pasaron de hasNewEpisode=false a hasNewEpisode=true y dispara
//  una notificación local por cada uno. Solo notifica UNA vez por
//  anime (no spamea cada 15 min si ya avisó).
//
//  Esto NO requiere FCM ni backend push: las notificaciones son
//  100% locales y se disparan desde el Worker.
// =========================================================

class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val syncManager = SyncManager.getInstance(applicationContext)
        val session = syncManager.state.value

        // Si no hay sesión, no hacer nada
        if (session is SyncState.LoggedOut) return Result.success()

        return try {
            // 1. Crear canal de notificaciones (idempotente)
            AnimeNotificationsManager.createNotificationChannel(applicationContext)

            // 2. Sync normal (pull + push)
            syncManager.pull()
            syncManager.push()

            // 3. Capturar estado ANTES de verificar (cuáles ya tenían hasNewEpisode=true)
            val dao = AnimeDatabase.getDatabase(applicationContext).animeDao()
            val stateBefore = dao.getAiringWatchHistory().associateBy { it.anilistId }
            val alreadyNotifiedAnimes = stateBefore.values
                .filter { it.hasNewEpisode }
                .map { it.anilistId }
                .toSet()

            // 4. Verificar animes en "En espera" vía AiringController
            try {
                val airingController = AiringController.getInstance(applicationContext)
                val updated = airingController.checkAllWaiting()
                if (updated > 0) {
                    Log.i("SyncWorker", "✅ $updated animes en espera actualizados")
                    // Hacer push de los cambios
                    syncManager.push()

                    // 5. NUEVO Fase 5: detectar animes que pasaron de false a true
                    // y enviar notificación por cada uno (solo los NUEVOS)
                    val stateAfter = dao.getAiringWatchHistory()
                    val newlyAvailableAnimes = stateAfter.filter { history ->
                        // Solo notificar si tiene hasNewEpisode=true AHORA y
                        // NO tenía hasNewEpisode=true antes (evita spamear)
                        history.hasNewEpisode &&
                        history.anilistId !in alreadyNotifiedAnimes &&
                        history.anilistId > 0
                    }

                    if (newlyAvailableAnimes.isNotEmpty()) {
                        Log.i("SyncWorker", "🔔 ${newlyAvailableAnimes.size} animes con nuevos episodios para notificar")

                        // Verificar permiso antes de mandar
                        if (AnimeNotificationsManager.hasPermission(applicationContext)) {
                            newlyAvailableAnimes.forEach { history ->
                                try {
                                    AnimeNotificationsManager.showNewEpisodeNotification(
                                        applicationContext,
                                        history
                                    )
                                } catch (e: Exception) {
                                    Log.e("SyncWorker", "Error enviando notificación para ${history.title}: ${e.message}")
                                }
                            }
                        } else {
                            Log.w("SyncWorker", "Sin permiso de notificaciones, no se enviaron")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("SyncWorker", "Error en AiringController: ${e.message}")
            }

            Result.success()
        } catch (e: Exception) {
            Log.e("SyncWorker", "Error general en SyncWorker: ${e.message}")
            Result.retry()
        }
    }
}
