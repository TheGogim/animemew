# Fase 4 — Mejoras del Reproductor

## Qué hace esta fase

Añade **5 features nuevas** al reproductor:

| # | Feature | Cómo se usa |
|---|---|---|
| **A2** | Picture-in-Picture (PiP) | Al salir de la app con Home button mientras un video reproduce → se muestra ventana flotante. Solo móvil. |
| **A5** | Visor de episodios en cuadrícula | Botón con ícono "lista" en top bar → abre bottom sheet con cuadrícula 5-columnas de todos los episodios. Tocás uno y cambiás de episodio sin salir del player. |
| **A7** | Gestos avanzados | Solo móvil. Doble tap izquierda/derecha = ±10s. Deslizar verticalmente en mitad izquierda = brillo. Deslizar verticalmente en mitad derecha = volumen. |
| **A8** | Selector de velocidad | Botón con "1.0x" en top bar → bottom sheet con opciones: 0.5x, 0.75x, 1.0x, 1.25x, 1.5x. Con pitch correction. |
| **A9** | Lock de pantalla | Botón con ícono candado en top bar → bloquea todos los controles. Solo visible el botón de unlock. |

## Cómo se ve

### Top bar del player (de izquierda a derecha)

```
[← Back] | Título + Episodio label | [🔒] [1.0x] [≡] [📡 Cast] [Servers]
```

- 🔒 = Lock (solo móvil)
- 1.0x = Velocidad (solo móvil)
- ≡ = Lista de episodios (si hay más de 1)
- 📡 = Cast
- Servers = selector de servidores

### Gestos (solo móvil, no en TV)

| Gesto | Acción | Feedback visual |
|---|---|---|
| Doble tap mitad izquierda | Retroceder 10s | Icono ⏪ + "-10s" centro-izquierda |
| Doble tap mitad derecha | Avanzar 10s | Icono ⏩ + "+10s" centro-derecha |
| Deslizar ↑↓ en mitad izquierda | Ajustar brillo | Barra vertical con % de brillo |
| Deslizar ↑↓ en mitad derecha | Ajustar volumen | Barra vertical con valor 0-15 |

### Lock de pantalla

- Al activar: overlay translúcido negro + botón central de unlock
- Bloquea todos los toques (no seek, no gestos, no controles)
- Solo se desbloquea tocando el botón unlock
- Útil para ver anime acostado sin toques accidentales

### PiP (Picture-in-Picture)

- Al salir de la app con Home button → se abre ventana flotante
- El video sigue reproduciendo en la ventanita
- Tocás la ventanita → volvés a la app
- Funciona solo en Android 8.0+ (API 26+) y si el manufacturer lo soporta
- Requiere `android:supportsPictureInPicture="true"` en AndroidManifest (ya está agregado)

## Cómo probar

1. Descomprimí `animemew-fase4.zip` en la raíz del proyecto
2. Compilá con `./gradlew :app:assembleDebug`
3. Abrí la app, entrá a un anime, reproducí un episodio
4. Verificá que en la top bar aparezcan los botones nuevos: candado, "1.0x", lista
5. **Probá el lock**: tocá el candado, los controles se ocultan. Tocá el centro para unlock.
6. **Probá la velocidad**: tocá "1.0x", seleccioná 1.5x, escuchá el audio (debería ser más rápido pero no chillon).
7. **Probá gestos**:
   - Doble tap a la izquierda → retrocede 10s
   - Doble tap a la derecha → avanza 10s
   - Deslizá verticalmente en la mitad izquierda → cambia el brillo
   - Deslizá verticalmente en la mitad derecha → cambia el volumen
8. **Probá visor de episodios**: tocá el ícono de lista, abrí la cuadrícula, tocá cualquier episodio → cambia sin salir del player.
9. **Probá PiP**: mientras reproduce, presioná Home button → aparece la ventana flotante. Tocá la ventana para volver.

## Archivos incluidos

**Nuevos:**
- `app/src/main/java/com/mew/animemew/ui/components/PlayerGestures.kt` — gestos A7

**Modificados:**
- `app/src/main/java/com/mew/animemew/ui/screens/PlayerScreen.kt` — añade 3 botones nuevos + 3 sheets nuevos + integración de gestos
- `app/src/main/java/com/mew/animemew/MainActivity.kt` — añade `onUserLeaveHint()` y `onPictureInPictureModeChanged()` para PiP
- `app/src/main/AndroidManifest.xml` — añade `android:supportsPictureInPicture="true"` a la activity

## Lo que NO cambia

- ✅ Funciona todo lo anterior: Cast, AiringController, Horarios, etc.
- ✅ Compatible con TV (los gestos y botones de velocidad/lock se ocultan en TV)
- ✅ Compatible con móvil y tablet
- ✅ No toca backend, ni AniList, ni scrapers
- ✅ No rompe el botón "Saltar OP" existente
- ✅ No rompe el auto-play siguiente episodio

## Notas técnicas

### Detección TV vs móvil

Para ocultar gestos y botones de velocidad en TV, uso:

```kotlin
val isTv = config.uiMode and Configuration.UI_MODE_TYPE_MASK == UI_MODE_TYPE_TELEVISION
val isMobile = !isTv
```

Si `isMobile = false`, no se renderiza:
- El overlay de gestos
- El botón de lock
- El botón de velocidad

El botón de episodios (≡) y el botón de Cast siguen disponibles en TV.

### Brillo: persistencia

El brillo se setea con `WindowManager.LayoutParams.screenBrightness`. Esto solo afecta a la Activity actual. Al salir del player, se restaura automáticamente al brillo del sistema. NO persiste fuera del player (esto es deseable — no queremos que el usuario quede con brillo bajo en toda la app).

### PiP: solo cuando hay video

El `onUserLeaveHint()` se llama SIEMPRE que el usuario sale de la app con Home button. Si no hay video reproduciéndose, Android simplemente no entra en PiP (no muestra la ventana flotante). Es seguro.

Si querés que SOLO entre en PiP cuando hay video reproduciéndose, podrías agregar un flag global `PlayerViewModel.isPlaying` y verificarlo antes de llamar `enterPictureInPictureMode`. Por ahora lo dejamos así (Android maneja el caso).

### Velocidad: pitch correction

ExoPlayer tiene `PlaybackParameters(speed, pitch)`. Pasar `pitch=1.0f` mantiene el tono original. Si pasa `pitch=speed`, suena agudo/grave. Nosotros mantenemos pitch=1.0f.

## Posibles errores de compilación

Si te falla algún import o algo, decime. Verifiqué los imports que añadí. Los más delicados:

- `androidx.compose.foundation.lazy.grid.GridCells` — para la cuadrícula de episodios
- `androidx.compose.foundation.lazy.grid.LazyVerticalGrid` — ídem
- `androidx.compose.foundation.lazy.grid.items` — ídem
- `androidx.media3.common.PlaybackParameters` — para velocidad
- `androidx.compose.foundation.gestures.detectDragGestures` — para gestos

Todos están en librerías que ya tenés en `libs.versions.toml` (compose BOM + media3).

## Lo siguiente

Cuando termines de probar esta fase, las siguientes son:

- **Fase 5**: Notificaciones push de nuevos episodios + segundas temporadas
- **Fase 6**: Recomendaciones + info enriquecida (personajes, staff)

Y cuando arregles el server MySQL, podemos añadir comentarios en detalles (D3).
