# Fase 3 — Pestaña Horarios

## Qué hace esta fase

Añade una nueva pestaña **"Horarios"** al bottom nav, entre "Listas" y "Ajustes". Esta pestaña muestra los horarios de emisión de los próximos episodios de animes en emisión, con 2 tabs:

1. **Siguiendo**: solo los animes que estás siguiendo (los que tenés en "En espera" con `isAiring=true`)
2. **Esta temporada**: los 50+ animes más populares en emisión ahora mismo

## Cómo funciona

### Tab "Siguiendo"

1. Lee todos los animes con `isAiring=true` de `watch_history` (los mismos que el AiringController verifica)
2. Para cada uno, consulta AniList `getAnimeDetails(anilistId)` en paralelo (hasta 5 simultáneos)
3. Toma el `nextAiringEpisode.airingAt` (Unix timestamp UTC)
4. Convierte a hora Colombia (`America/Bogota`, UTC-5, sin DST)
5. Extrae día de la semana y hora
6. Agrupa por día y ordena cronológicamente dentro de cada día

### Tab "Esta temporada"

1. Llama a `searchAnime(status=RELEASING, sort=FAVOURITES_DESC, perPage=20)` hasta 3 veces (hasta 60 animes)
2. Toma los que tienen `nextAiringEpisode` (descarta los que no tienen fecha de próximo episodio)
3. Convierte y agrupa igual que el tab anterior
4. Marca los que están en "Siguiendo" con un borde púrpura y label "Siguiendo"

### Zona horaria

AniList devuelve `airingAt` como Unix timestamp en UTC. La app lo convierte a `America/Bogota` (UTC-5). Ejemplo:

- AniList: `airingAt: 1789311600` (Jueves 3 de abril 2025, 00:00 UTC)
- Convertido: `ZonedDateTime = 2025-04-02T19:00-05:00` (Miércoles 2 de abril, 7:00 PM hora Colombia)

### Recarga

- Se recarga al abrir la pestaña (`init { loadSchedule() }`)
- Hay un botón de refresh (icono circular arriba a la derecha) por si querés forzar la recarga
- No consume datos en background (no está conectado al SyncWorker)

## UI

```
┌───────────────────────────────────┐
│  📅 Horarios                       │
│  Tus animes en emisión      🔄    │
├───────────────────────────────────┤
│  [Siguiendo] [Esta temporada]    │
├───────────────────────────────────┤
│  ▎ MIÉRCOLES · 3 animes           │
│  ┌─────────────────────────────┐  │
│  │ [cover] Naruto        E1123 │  │
│  │         02 abr       7:00PM │  │
│  │                    Siguiendo│  │
│  └─────────────────────────────┘  │
│  ┌─────────────────────────────┐  │
│  │ [cover] One Piece    E1178  │  │
│  │         02 abr       6:15PM │  │
│  └─────────────────────────────┘  │
│                                   │
│  ▎ JUEVES · 2 animes             │
│  ┌─────────────────────────────┐  │
│  │ [cover] Mushoku T.   E12    │  │
│  │         03 abr      10:00 AM │  │
│  └─────────────────────────────┘  │
└───────────────────────────────────┘
```

## Cómo probar

1. Descomprimí el ZIP en la raíz del proyecto
2. Compilá con `./gradlew :app:assembleDebug`
3. Abrí la app
4. Vas a ver un nuevo ícono en el bottom nav (entre "Listas" y "Ajustes") — es un reloj con la palabra "Horarios"
5. Tocá la pestaña → cargará el tab "Siguiendo" por defecto
6. Si tenés animes en "En espera" (siguiendo), los vas a ver agrupados por día de la semana
7. Tocá "Esta temporada" → carga los 50+ animes populares en emisión
8. Tocá cualquier anime → abre su detalle

## Archivos incluidos

**Nuevos:**
- `app/src/main/java/com/mew/animemew/ui/screens/ScheduleScreen.kt` — UI de la pestaña
- `app/src/main/java/com/mew/animemew/ui/viewmodels/ScheduleViewModel.kt` — lógica (carga de AniList + conversión de zona horaria)

**Modificados:**
- `app/src/main/java/com/mew/animemew/navigation/BottomNavItem.kt` — añade el item "Schedule"
- `app/src/main/java/com/mew/animemew/ui/screens/MainAppScreen.kt` — añade la ruta `schedule` al NavHost

## Lo que NO cambia

- ✅ No toca AniList ni el ApolloClient
- ✅ No toca Room/DB
- ✅ No toca los scrapers
- ✅ No toca el AiringController (sigue funcionando igual)
- ✅ No toca el backend de sync
- ✅ Compatible con Fase 1, 1.5 y 2 — todo lo anterior sigue funcionando

## Notas técnicas

### Zona horaria

Usamos `java.time.ZoneId.of("America/Bogota")` (UTC-5 sin DST). AniList da `airingAt` en UTC segundos, lo convertimos con:

```kotlin
val bogotaTime = Instant.ofEpochSecond(airingAt).atZone(bogotaZone)
val dayOfWeek = bogotaTime.dayOfWeek   // MONDAY, TUESDAY...
val hour = bogotaTime.hour              // 0-23
val minute = bogotaTime.minute          // 0-59
```

### minSdk

`java.time` requiere API 26+. Tu `minSdk = 24`. Para que no rompa en Android 7 (API 24-25), el desugaring de `java.time` viene habilitado por defecto en AGP 8.0+ con `compileSdk = 36` y `coreLibraryDesugaringEnabled = true`. Como tu `compileSdk = 36` y AGP = 9.1.1, debería funcionar sin tocar el gradle.

Si por alguna razón no compila por `java.time`, agregá esto a `app/build.gradle.kts`:

```kotlin
compileOptions {
    isCoreLibraryDesugaringEnabled = true
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}
dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
```

(Pero repito, debería funcionar sin tocar nada porque AGP 9 lo trae por defecto).

### Performance

- Las llamadas a AniList para el tab "Siguiendo" se hacen en paralelo con `async` + `awaitAll` (hasta 5 simultáneos en realidad son todos, no limité concurrencia).
- El tab "Esta temporada" hace 3 requests secuenciales de 20 animes cada uno. Con rate limit alto de AniList (ahora que tiene los headers correctos), tarda menos de 3 segundos.
- El cache es solo en memoria dentro del ViewModel (no persiste). Se pierde al cerrar la app o rotar pantalla. Esto es intencional para que siempre tengas datos frescos al abrir la pestaña.

## Errores conocidos

- Si tenés 0 animes en "En espera", el tab "Siguiendo" muestra un estado vacío con mensaje "No estás siguiendo animes en emisión".
- Si AniList no responde para algún anime específico, ese anime se salta (no rompe el resto).
- Si la lista de "Esta temporada" trae animes sin `nextAiringEpisode`, se descartan silenciosamente.
