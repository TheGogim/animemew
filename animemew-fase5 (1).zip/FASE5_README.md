# Fase 5 — Notificaciones de Nuevos Episodios

## Qué hace esta fase

Cuando el `SyncWorker` (que corre cada 15 min) detecta que un anime que estás siguiendo en "Continuar viendo" tiene nuevos episodios disponibles, envía una notificación local con:

- Título del anime + icono 📺
- Cover del anime (estilo big picture)
- Cuerpo: "X episodios nuevos disponibles" o "Episodio N ya disponible"
- Al tocar: abre directamente el reproductor en el episodio donde estabas (NO en el último disponible)

**No requiere FCM ni servidor push**: las notificaciones son 100% locales, disparadas por WorkManager.

## Cómo funciona

### Flujo de detección

1. `SyncWorker` corre cada 15 min en background (ya estaba configurado así).
2. Antes de llamar `airingController.checkAllWaiting()`, captura qué animes ya tenían `hasNewEpisode=true` (para no repetir notificaciones).
3. Después de verificar, busca animes que pasaron de `false` a `true`.
4. Para cada uno, llama a `AnimeNotificationsManager.showNewEpisodeNotification()`.

### Evitar spam de notificaciones

- Solo notifica **una vez por anime** — si `hasNewEpisode` ya era `true` antes, no re-notifica.
- Si la app está abierta y el usuario ya vio el badge en "Continuar viendo", igualmente va a recibir la notificación (porque es la primera vez). Esto es deseable: la notificación es el "empujón" para abrir la app.
- Si el usuario abre el anime desde la notificación, se cancela esa notificación automáticamente.

### Deep link: tocar notificación → abrir player

Cuando el usuario toca la notificación:
1. `PendingIntent` abre `MainActivity` con un URI: `animemew://player/{slug}/{episode}`
2. `MainActivity.handleDeepLinkFromNotification()` parsea el URI y los extras (título, cover, etc.)
3. Los guarda en `MainActivity.pendingDeepLink` (variable estática)
4. `MainAppScreen` en su `LaunchedEffect(Unit)` lee ese `pendingDeepLink` y navega al `player/{slug}/{episode}` route, igual que si el usuario hubiera tocado una card de "Continuar viendo".

## Permisos

### Android 13+ (API 33+)

Requiere permiso runtime `POST_NOTIFICATIONS`. La app lo pide automáticamente al iniciar (en `MainActivity.onCreate`).

Si el usuario lo rechaza:
- La app sigue funcionando normalmente
- No se muestran notificaciones, pero los badges dorados "+N" en "Continuar viendo" siguen apareciendo (esos no requieren permiso)

### Android 12 y anteriores

No requieren permiso runtime. La notificación aparece directamente.

## Archivos incluidos

**Nuevos:**
- `app/src/main/java/com/mew/animemew/notifications/AnimeNotificationsManager.kt` — gestiona canal + notificaciones + deep link PendingIntent

**Modificados:**
- `app/src/main/java/com/mew/animemew/data/sync/SyncWorker.kt` — detecta `hasNewEpisode=false → true` y dispara notificaciones
- `app/src/main/java/com/mew/animemew/MainActivity.kt` — crea canal, pide permiso, maneja deep link
- `app/src/main/java/com/mew/animemew/ui/screens/MainAppScreen.kt` — escucha `pendingDeepLink` y navega al player
- `app/src/main/AndroidManifest.xml` — añade `<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />`

## Cómo probar

1. Descomprimí `animemew-fase5.zip` en la raíz del proyecto
2. Compilá con `./gradlew :app:assembleDebug`
3. Al abrir la app por primera vez → Android va a pedir permiso de notificaciones → **Aceptá**
4. Para probar que funciona:
   - Tené un anime en "En espera" (uno que ya viste todos los eps disponibles pero sigue en emisión)
   - Esperá que el `SyncWorker` corra (puede tardar hasta 15 min) O forzá sync desde Settings → "Sincronizar ahora"
   - Si hay un episodio nuevo en jkanime/tioanime, vas a recibir una notificación
5. Tocá la notificación → abre la app y navega directamente al player en el episodio donde estabas

## Verificar en logcat

Filtrá por `SyncWorker` y `AnimeNotifs`:

```
SyncWorker: ✅ 2 animes en espera actualizados
SyncWorker: 🔔 1 animes con nuevos episodios para notificar
AnimeNotifs: ✅ Notificación enviada para Naruto (+1 eps)
```

Si ves "Sin permiso de notificaciones, no se enviaron" → revisá que el usuario tenga concedido el permiso en Settings del sistema.

## Lo que NO cambia

- ✅ AniList, Apollo, scrapers, sync cloud, todo igual
- ✅ AiringController rediseñado intacto
- ✅ Pestaña Horarios intacta
- ✅ Player improvements (PiP, gestos, lock, velocidad, lista episodios) intactos
- ✅ CrashOverlay intacto
- ✅ Backend no se toca

## Limitaciones conocidas

### 1. No notifica si el usuario mata la app con force-stop

Android mata el WorkManager cuando el usuario hace force-stop desde Settings. Esto es comportamiento estándar de Android. Si el usuario simplemente sale de la app con swipe-up (no force-stop), el Worker sigue corriendo.

### 2. Solo notifica si hay sesión activa

El `SyncWorker` hace `return Result.success()` si no hay sesión. Esto es porque el sync cloud requiere sesión. Si querés notificaciones sin sesión, habría que separar el check de airing del check de sync. Por ahora queda así (según tu app, todos los usuarios que usan "Continuar viendo" deberían tener sesión).

### 3. Coil para cargar cover

Usé Coil (que ya está en tus deps) para cargar la cover del anime como bitmap. Si la cover falla (URL inválida, sin internet), la notificación se muestra igual pero sin imagen (solo texto).

### 4. Cover del anime puede no actualizarse

La notificación usa `history.coverUrl` que es la cover guardada en `watch_history` cuando el usuario vio el anime. Si AniList actualiza la cover, la notificación mostraría la vieja. Esto es un trade-off aceptable (no hacemos un request a AniList solo para la cover de la notificación).

## Próximos pasos

Si todo funciona, las siguientes opciones son:

- **C4 Notificaciones de segundas temporadas anunciadas** — cuando AniList actualiza con `relation: SEQUEL`, avisar a los usuarios que lo tienen en "Visto"
- **D3 Comentarios en detalle** — cuando arregles MySQL
- **B1+B2 Recomendaciones + info enriquecida** — usando AniList GraphQL

Decime qué querés hacer después.
